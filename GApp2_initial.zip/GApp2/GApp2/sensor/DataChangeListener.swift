//
//  DataChangeListener.swift
//  GApp
//
//  Created by Robert Talianu
//


public protocol DataChangeListener {
    
    /**
     * @return
     */
    func onDataChange();
}
