//
//  GApp2App.swift
//  GApp2
//
//  Created by Robert Talianu on 12.12.2024.
//

import SwiftUI

@main
struct GApp2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
